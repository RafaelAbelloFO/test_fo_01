def holamundo():
    print("Hola mundo")