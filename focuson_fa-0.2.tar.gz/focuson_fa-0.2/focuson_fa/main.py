from fastapi import FastAPI, HTTPException
from focuson_fa.captura import capturar_pantalla
app = FastAPI()

@app.get("/captura/{url}")
def captura(url: str):
    destino = f"{url.replace('/', '_')}.png"
    try:
        capturar_pantalla(url, destino)
        return {"mensaje": "Captura realizada con éxito", "archivo": destino}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error al capturar pantalla: {str(e)}")
