from playwright.sync_api import sync_playwright
def capturar_pantalla(url, destino):
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page()
        page.goto(url)
        page.screenshot(path=destino)
        browser.close()
