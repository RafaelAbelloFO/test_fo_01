import pytest
from focuson_fa.captura import capturar_pantalla

@pytest.mark.parametrize("url", ["http://example.com", "http://google.com"])
def test_capturar_pantalla(tmpdir, url):
    destino = str(tmpdir.join(f"{url.replace('/', '_')}.png"))
    capturar_pantalla(url, destino)
    assert tmpdir.join(f"{url.replace('/', '_')}.png").exists()
